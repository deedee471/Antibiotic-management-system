-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 24, 2024 at 01:50 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `prescription_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `allergy`
--

CREATE TABLE `allergy` (
  `_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` varchar(500) NOT NULL,
  `severity` enum('HIGH','NORMAL','LOW') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `antibiotics`
--

CREATE TABLE `antibiotics` (
  `_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` varchar(200) NOT NULL,
  `manufacturer` varchar(200) NOT NULL,
  `age_range` varchar(200) NOT NULL,
  `quantity` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `antibiotics`
--

INSERT INTO `antibiotics` (`_id`, `name`, `description`, `manufacturer`, `age_range`, `quantity`) VALUES
(1, 'Mara Moja', 'For Headaches and other body pains', 'KEMSA', 'Above 5 years', 300),
(2, 'Panadol', 'Painkiller', 'KEMSA', 'Above 10 years', 200);

-- --------------------------------------------------------

--
-- Table structure for table `drug_illness`
--

CREATE TABLE `drug_illness` (
  `_id` int(11) NOT NULL,
  `antibiotic_id` int(11) NOT NULL,
  `illness_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `illness`
--

CREATE TABLE `illness` (
  `_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `_id` int(11) NOT NULL,
  `user_id` int(200) NOT NULL,
  `action` varchar(500) NOT NULL,
  `created_at` datetime NOT NULL,
  `related_to` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`_id`, `user_id`, `action`, `created_at`, `related_to`) VALUES
(3, 7, 'Mervin Wachira has logged in to the system', '2024-05-23 23:36:34', 'User'),
(4, 6, 'Kigogo has been added as an Admin by Super Admin', '2024-05-24 00:06:41', 'User'),
(5, 6, 'Profile for Jeff has been updated by Super Admin', '2024-05-24 00:09:12', 'User'),
(6, 7, 'Mervin Wachira has logged in to the system', '2024-05-24 02:20:42', 'User'),
(7, 7, 'Mervin Wachira has logged in to the system', '2024-05-24 02:30:42', 'User'),
(8, 7, 'Antibiotic Mara Moja has updated added by Mervin Wachira', '2024-05-24 02:38:54', 'Antibiotic');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `_id` int(11) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `age` int(100) NOT NULL,
  `phone_number` varchar(200) NOT NULL,
  `email` varchar(100) NOT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `next_of_kin_first_name` varchar(100) DEFAULT NULL,
  `next_of_kin_last_name` varchar(100) DEFAULT NULL,
  `next_of_kin_relationship` enum('Mother','Father','Sister','Brother','Spouce','Child') DEFAULT NULL,
  `next_of_kin_phone_number` varchar(20) DEFAULT NULL,
  `next_of_kin_email` varchar(100) DEFAULT NULL,
  `allergy` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`_id`, `first_name`, `last_name`, `age`, `phone_number`, `email`, `gender`, `created_at`, `updated_at`, `next_of_kin_first_name`, `next_of_kin_last_name`, `next_of_kin_relationship`, `next_of_kin_phone_number`, `next_of_kin_email`, `allergy`) VALUES
(1, 'Lucy', 'Wanjiku', 19, '0745336899', 'lucy87@gmail.com', 'Female', '2024-03-30 14:35:00', '2024-05-07 01:00:21', 'Martha', 'Wanjiku', 'Mother', '0724663191', 'mwanjiku@gmail.com', 'Lactose Intolerance'),
(2, 'Brian', 'Okello', 22, '0712334556', 'brianok21@gmail.com', 'Male', '2024-03-30 14:43:01', '0000-00-00 00:00:00', 'Amos', 'Gitonga', 'Brother', '0723566733', 'amgitz84@gmail.com', 'N/A'),
(3, 'Beatrice', 'Kihara', 34, '0721348235', 'bkihara54@gmail.com', 'Female', '2024-03-30 17:04:37', '0000-00-00 00:00:00', 'Andrew', 'Kuria', '', '0733462882', 'andrewkk@gmail.com', 'None'),
(4, 'John ', 'Kamunya', 54, '0722335478', 'johnkamunya43@gmail.com', 'Male', '2024-03-30 17:08:16', '0000-00-00 00:00:00', 'Samuel', 'Karanja', 'Father', '0727519663', 'samkaranja22@gmail.com', 'Asthma'),
(11, 'Brenda', 'Wanjiru', 21, '0722387491', 'brenda01@gmail.com', 'Female', '2024-05-20 10:58:54', '0000-00-00 00:00:00', 'Mervin', 'Wachira', 'Brother', '0759839644', 'mervin43@gmail.com', 'N/A');

-- --------------------------------------------------------

--
-- Table structure for table `patient_allergy`
--

CREATE TABLE `patient_allergy` (
  `_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `allergy_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `patient_illness`
--

CREATE TABLE `patient_illness` (
  `_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `illness_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `prescription`
--

CREATE TABLE `prescription` (
  `_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `administered_by` int(11) NOT NULL,
  `description` varchar(200) NOT NULL,
  `dosage` varchar(200) NOT NULL,
  `antibiotic_id` int(11) NOT NULL,
  `frequency` varchar(200) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `prescription`
--

INSERT INTO `prescription` (`_id`, `patient_id`, `administered_by`, `description`, `dosage`, `antibiotic_id`, `frequency`, `start_date`, `end_date`) VALUES
(1, 2, 7, 'For the Pain and Backache', '15 tablets', 1, '1x3', '2024-04-08', '2024-04-13'),
(2, 1, 7, 'For the headaches', '10 tablets', 1, '1x2', '2024-04-01', '2024-04-05'),
(4, 1, 7, 'For the headaches', '10 tablets', 1, '1x2', '2024-04-08', '2024-04-12'),
(5, 2, 7, 'For the Pain and Backache', '15 tablets', 1, '1x3', '2024-04-22', '2024-04-28');

-- --------------------------------------------------------

--
-- Table structure for table `reset_password_tokens`
--

CREATE TABLE `reset_password_tokens` (
  `_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `token` varchar(255) NOT NULL,
  `expirationDate` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reset_password_tokens`
--

INSERT INTO `reset_password_tokens` (`_id`, `user_id`, `token`, `expirationDate`, `created_at`) VALUES
(4, 7, '69fcc1dc89eb47fb293fa6928a00cac9', '2024-05-19 14:09:29', '2024-05-19 11:54:29'),
(5, 7, '4897d2be7de01bda3b15f4ce7b21e393', '2024-05-19 16:25:53', '2024-05-19 14:10:53'),
(6, 7, '648965b7b41c45452dd9fcc2694fcd02', '2024-05-19 16:47:57', '2024-05-19 14:32:57'),
(7, 7, '40078f8e4338bc14757b8f1de4bcee76', '2024-05-19 22:52:09', '2024-05-19 19:37:09'),
(8, 7, 'd1deaef869af9aac6cac375cdcb79a38', '2024-05-19 23:19:45', '2024-05-19 20:04:45'),
(9, 7, 'e46e89c0f25e2f563bfc9d73e2f18fc2', '2024-05-20 00:05:32', '2024-05-19 20:50:32'),
(10, 7, '18cd6d69f3ddd45c3a09b0910ca622d3', '2024-05-20 01:09:58', '2024-05-19 21:54:58'),
(11, 7, '753f2ea1b361f90f7ff6533011198701', '2024-05-21 23:04:10', '2024-05-21 19:49:10'),
(12, 7, '8d4c680b74a855335435621b2dc71a29', '2024-05-22 01:42:16', '2024-05-21 22:27:16'),
(13, 15, '1ce393d64387d925ca818bae5a7811d7', '2024-05-22 01:44:31', '2024-05-21 22:29:31');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `phone_number` varchar(13) NOT NULL,
  `email` varchar(100) NOT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `password` varchar(500) NOT NULL,
  `role` enum('ADMIN','DOCTOR','SUPERADMIN') NOT NULL,
  `specialization` varchar(200) NOT NULL,
  `job_id` varchar(50) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`_id`, `name`, `phone_number`, `email`, `gender`, `password`, `role`, `specialization`, `job_id`, `created_at`, `updated_at`) VALUES
(6, 'Super Admin', '+254780222456', 'admin1@gmail.com', 'Male', '$2y$10$u8B0uK/5I1yWbaQW1BB2/utUJVSlGFO8crgEcvD4DFnofw.gy31ou', 'SUPERADMIN', '', 'SAD34512', '2024-03-24 14:58:09', '0000-00-00 00:00:00'),
(7, 'Mervin Wachira', '0759839644', 'marvinwachira6@gmail.com', 'Male', '$2y$10$gWrDp1pEYPWn4yhsvuV9Ce.fMo0NofMCGYlcSn2jowOhr9cSj.Yt6', 'DOCTOR', 'Neuro Surgeon', 'DOC23364', '2024-03-24 16:03:58', '2024-05-19 23:54:31'),
(8, 'Jeff', '0724893554', 'jeff@gmail.com', 'Male', '$2y$10$6O.oaUo3TsHhsh5J3DXe9eM4jYOAj4gIT0Qg77eKzHIw8Xb/judUS', 'ADMIN', '', 'ADM55497', '2024-03-24 21:44:36', '2024-05-24 00:09:12'),
(9, 'Joseph Mukunga', '0744678943', 'joseh@gmail.com', 'Male', '$2y$10$DvPBgh5tEILGWX1GbNjCluoDwIVfDxMzVkQSQI3ONQsFRpZhUcuGu', 'DOCTOR', 'Physio Therapist', 'DOC78325', '2024-04-02 12:47:07', '2024-04-02 15:28:34'),
(11, 'Melisa', '0721335543', 'melidiva23@gmail.com', 'Female', '$2y$10$UemEIXT0HVewtUuiLEYL4OnhjxvHcvUXTjXnl0qBMlQTn35jBQZ9e', 'ADMIN', '', 'ADM45632', '2024-04-02 14:05:19', '2024-04-02 15:27:13'),
(13, 'Mercy Wahito', '0723452278', 'wahito22@gmail.com', 'Female', '$2y$10$i5lLNFRVQ6yLDV1bzQeph.4ZOGpY7G0Z01WNMqMohlgaKfcM68tFu', 'DOCTOR', 'Doctor', 'VH5782', '2024-05-19 09:36:07', '0000-00-00 00:00:00'),
(14, 'John Kinuthia', '0716334872', 'kinuthia26@gmail.com', 'Male', '$2y$10$vnRE4NX1i0PFS2eqCpNZzeMQ.VtOflvm/BZ6fWcThsMJ6PpGC3OLq', 'ADMIN', '', 'VH7822', '2024-05-19 10:03:44', '2024-05-19 10:07:19'),
(15, 'Dee', '0715437335', 'dianakalee05@gmail.com', 'Female', '$2y$10$sc594PF7QkjpO.BNlSzkp.Law59SgW59NpwHkyH/oDRdEZpZwp/L2', 'DOCTOR', 'Surgeon', 'VH7844', '2024-05-22 01:29:17', '0000-00-00 00:00:00'),
(16, 'Kigogo', '0716227883', 'kigogo54@gmail.com', 'Male', '$2y$10$f/G.cVOno6fXkU1EMOVFCu4FY/AAHTCP62iVWsXpnbIlIr5FGzLM.', 'ADMIN', '', 'VH6703', '2024-05-24 00:06:41', '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `allergy`
--
ALTER TABLE `allergy`
  ADD PRIMARY KEY (`_id`);

--
-- Indexes for table `antibiotics`
--
ALTER TABLE `antibiotics`
  ADD PRIMARY KEY (`_id`);

--
-- Indexes for table `drug_illness`
--
ALTER TABLE `drug_illness`
  ADD PRIMARY KEY (`_id`),
  ADD KEY `antibiotic_id` (`antibiotic_id`),
  ADD KEY `illness_id` (`illness_id`);

--
-- Indexes for table `illness`
--
ALTER TABLE `illness`
  ADD PRIMARY KEY (`_id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`_id`),
  ADD KEY `userlog` (`user_id`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`_id`);

--
-- Indexes for table `patient_allergy`
--
ALTER TABLE `patient_allergy`
  ADD PRIMARY KEY (`_id`),
  ADD KEY `allergy_id` (`allergy_id`),
  ADD KEY `patient_id` (`patient_id`);

--
-- Indexes for table `patient_illness`
--
ALTER TABLE `patient_illness`
  ADD PRIMARY KEY (`_id`),
  ADD KEY `illness_id` (`illness_id`),
  ADD KEY `patient_id` (`patient_id`);

--
-- Indexes for table `prescription`
--
ALTER TABLE `prescription`
  ADD PRIMARY KEY (`_id`),
  ADD KEY `patient_id` (`patient_id`),
  ADD KEY `antibiotic_id` (`antibiotic_id`),
  ADD KEY `administered_by` (`administered_by`);

--
-- Indexes for table `reset_password_tokens`
--
ALTER TABLE `reset_password_tokens`
  ADD PRIMARY KEY (`_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `allergy`
--
ALTER TABLE `allergy`
  MODIFY `_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `antibiotics`
--
ALTER TABLE `antibiotics`
  MODIFY `_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `drug_illness`
--
ALTER TABLE `drug_illness`
  MODIFY `_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `illness`
--
ALTER TABLE `illness`
  MODIFY `_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `patient_allergy`
--
ALTER TABLE `patient_allergy`
  MODIFY `_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `patient_illness`
--
ALTER TABLE `patient_illness`
  MODIFY `_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `prescription`
--
ALTER TABLE `prescription`
  MODIFY `_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `reset_password_tokens`
--
ALTER TABLE `reset_password_tokens`
  MODIFY `_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `drug_illness`
--
ALTER TABLE `drug_illness`
  ADD CONSTRAINT `drug_illness_ibfk_1` FOREIGN KEY (`antibiotic_id`) REFERENCES `antibiotics` (`_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `drug_illness_ibfk_2` FOREIGN KEY (`illness_id`) REFERENCES `illness` (`_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `logs`
--
ALTER TABLE `logs`
  ADD CONSTRAINT `userlog` FOREIGN KEY (`user_id`) REFERENCES `user` (`_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `patient_allergy`
--
ALTER TABLE `patient_allergy`
  ADD CONSTRAINT `patient_allergy_ibfk_1` FOREIGN KEY (`allergy_id`) REFERENCES `allergy` (`_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `patient_allergy_ibfk_2` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `patient_illness`
--
ALTER TABLE `patient_illness`
  ADD CONSTRAINT `patient_illness_ibfk_1` FOREIGN KEY (`illness_id`) REFERENCES `illness` (`_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `patient_illness_ibfk_2` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `prescription`
--
ALTER TABLE `prescription`
  ADD CONSTRAINT `prescription_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `prescription_ibfk_2` FOREIGN KEY (`antibiotic_id`) REFERENCES `antibiotics` (`_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `prescription_ibfk_3` FOREIGN KEY (`administered_by`) REFERENCES `user` (`_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `reset_password_tokens`
--
ALTER TABLE `reset_password_tokens`
  ADD CONSTRAINT `reset_password_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
