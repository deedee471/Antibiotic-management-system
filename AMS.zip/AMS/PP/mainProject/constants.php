<?php

//constants to be used to aid db connection
 define('DB_Host','localhost');
 define('DB_User','root');
 define('DB_Pass','');
 define('DB_Name','prescription_system');
?>