<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sign Up</title>
  <style>
    /* Body styles */
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 0;
      background: linear-gradient(135deg, #e65b00, #ffc600, #e65b00); /* Adjusted background gradient */
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    /* Container styles */
    .container {
      max-width: 400px;
      width: 100%;
      background: rgba(255, 255, 255, 0.9);
      padding: 20px;
      border-radius: 20px;
      box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.2);
      text-align: center;
      position: relative;
      overflow: hidden;
      margin-top: 50px; /* Add margin to the top */
    }

    /* Title styles */
    h2 {
      color: #333;
      margin-bottom: 20px;
      font-size: 32px;
      letter-spacing: 1px;
    }

    /* Form group styles */
    .form-group {
      margin-bottom: 15px;
      text-align: left;
    }

    /* Label styles */
    label {
      display: block;
      font-weight: bold;
      margin-bottom: 5px;
      color: #666;
      font-size: 16px;
    }

    /* Input styles */
    input[type="text"],
    input[type="password"] {
      width: calc(100% - 24px);
      padding: 12px;
      border: none;
      border-radius: 10px;
      background-color: rgba(255, 255, 255, 0.9);
      color: #333;
      font-size: 14px;
      outline: none;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      transition: box-shadow 0.3s ease;
    }

    /* Input focus styles */
    input[type="text"]:focus,
    input[type="password"]:focus {
      box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
    }

    /* Submit button styles */
    input[type="submit"] {
      width: 100%;
      padding: 15px;
      border: none;
      border-radius: 10px;
      background: linear-gradient(to right, #e65b00, #f9a825); /* Enhanced gradient for button */
      color: #fff;
      font-size: 16px;
      cursor: pointer;
      transition: transform 0.2s ease;
    }

    /* Submit button hover styles */
    input[type="submit"]:hover {
      transform: scale(1.05);
    }

    /* Terms styles */
    .terms {
      font-size: 14px;
      color: #666;
      margin-top: 20px;
    }

    /* Terms link styles */
    .terms a {
      color: #e65b00;
      text-decoration: none;
    }

    /* Background shapes */
    .bg-circle {
      position: absolute;
      background: rgba(255, 255, 255, 0.2);
      border-radius: 50%;
    }

    .bg-circle:nth-child(1) {
      width: 150px;
      height: 150px;
      top: -75px;
      left: -75px;
    }

    .bg-circle:nth-child(2) {
      width: 250px;
      height: 250px;
      top: calc(50% - 125px);
      right: -125px;
    }

    .bg-circle:nth-child(3) {
      width: 200px;
      height: 200px;
      bottom: -100px;
      left: -100px;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="bg-circle"></div>
    <div class="bg-circle"></div>
    <div class="bg-circle"></div>
    <h2>Sign Up Now!</h2>
    <form action="#" method="post">
      <!-- Username Input Field -->
      <div class="form-group">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" placeholder="Enter your username" required>
        <small id="usernameHelpBlock" style="color: red;"></small> <!-- Disclaimer for incorrect username format -->
      </div>
      <!-- Email Input Field -->
      <div class="form-group">
        <label for="email">Email Address:</label>
        <input type="text" id="email" name="email" placeholder="e.g., name@gmail.com" required>
      </div>
      <!-- Contact Number Input Field -->
      <div class="form-group">
        <label for="contact">Contact Number:</label>
        <input type="text" id="contact" name="contact" placeholder="e.g., 0712345678" pattern="[0-9]{10}" title="Please enter a 10-digit phone number" required>
      </div>
      <!-- Password Input Field -->
      <div class="form-group">
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" placeholder="Enter your password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*\W)(?!.*\s).{8,}" title="Password must contain at least one number, one uppercase letter, one lowercase letter, one special character, and be at least 8 characters long" required>
      </div>
      <!-- Confirm Password Input Field -->
      <div class="form-group">
        <label for="confirm-password">Confirm Password:</label>
        <input type="password" id="confirm-password" name="confirm-password" placeholder="Confirm your password" required>
        <small id="passwordHelpBlock" style="color: red;"></small> <!-- Disclaimer for password mismatch -->
      </div>
      <!-- Submit Button -->
      <input type="submit" value="Sign Up">
    </form>
    <!-- Terms & Conditions Link -->
    <!-- Sign-in Link -->
    <a href="signin.html">Already have an account? Sign in</a>
    <p class="terms">By signing up, you agree to our <a href="#">Terms & Conditions</a>.</p>
  </div>
</body>
</html>
