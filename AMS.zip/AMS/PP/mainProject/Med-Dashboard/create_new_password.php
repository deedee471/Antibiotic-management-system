<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Create New Password</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    /* Body styles */
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 0;
      background: linear-gradient(135deg, #e65b00, #ffc600, #e65b00);
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    /* Wrapper styles */
    .wrapper {
      display: flex;
      flex-direction: column;
      align-items: center;
    }

    .error {
      background-color: #ffcccc;
      color: #cc0000;
      padding: 10px;
      margin-bottom: 20px;
      border-radius: 10px;
    }

    .success {
      background-color: #ccffcc;
      color: #006600;
      padding: 10px;
      margin-bottom: 20px;
      border-radius: 10px;
    }

    /* Container styles */
    .container {
      max-width: 400px;
      width: 100%;
      background: rgba(255, 255, 255, 0.9);
      padding: 20px;
      border-radius: 20px;
      box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.2);
      text-align: center;
      position: relative;
      overflow: hidden;
      margin-top: 20px;
    }

    /* Title styles */
    h2 {
      color: #333;
      margin-bottom: 20px;
      font-size: 32px;
      letter-spacing: 1px;
    }

    /* Form group styles */
    .form-group {
      margin-bottom: 15px;
      text-align: left;
    }

    /* Label styles */
    label {
      display: block;
      font-weight: bold;
      margin-bottom: 5px;
      color: #666;
      font-size: 16px;
    }

    /* Input styles */
    input[type="password"] {
      width: calc(100% - 24px);
      padding: 12px;
      border: none;
      border-radius: 10px;
      background-color: rgba(255, 255, 255, 0.9);
      color: #333;
      font-size: 14px;
      outline: none;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      transition: box-shadow 0.3s ease;
    }

    /* Password input field */
    .password-input {
      position: relative;
    }

    /* Eye icon */
    .toggle-password {
      position: absolute;
      right: 10px;
      top: 50%;
      transform: translateY(-50%);
      cursor: pointer;
    }

    /* Show eye icon when password is hidden */
    .password-hidden .toggle-password i::before {
      content: '\f06e'; /* Change eye icon to open */
    }

    /* Hide eye icon when password is revealed */
    .password-revealed .toggle-password i::before {
      content: '\f070'; /* Change eye icon to closed */
    }

    /* Input focus styles */
    input[type="password"]:focus {
      box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
    }

    /* Submit button styles */
    input[type="submit"] {
      width: 100%;
      padding: 15px;
      border: none;
      border-radius: 10px;
      background: linear-gradient(to right, #e65b00, #f9a825);
      color: #fff;
      font-size: 16px;
      cursor: pointer;
      transition: transform 0.2s ease;
    }

    /* Submit button hover styles */
    input[type="submit"]:hover {
      transform: scale(1.05);
    }

    /* Sign-in link styles */
    .sign-in-link {
      color: #e65b00;
      text-decoration: none;
      margin-top: 20px;
      display: block;
    }

    /* Welcome title styles */
    .welcome-title {
      font-size: 48px;
      color: #fff;
      text-align: center;
      margin-bottom: 30px;
      text-shadow: 3px 3px 6px rgba(0, 0, 0, 0.4);
      background: -webkit-linear-gradient(left, #f9a825, #e65b00);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      animation: shine 3s linear infinite;
    }

    /* Shine animation */
    @keyframes shine {
      0% {
        background-position: -1000px;
      }
      100% {
        background-position: 1000px;
      }
    }
  </style>
</head>
<body>
  <div class="wrapper">
    <!-- Welcome title -->
    <div class="welcome-title">Welcome to Victory Hospital</div>

    <div class="container">
      <h2>Create New Password</h2>
      <div id="errorMessages"></div> <!-- Div to display error messages -->
      <form id="resetPasswordForm">
        <!-- New Password Input Field -->
        <div class="form-group">
          <label for="new-password">New Password:</label>
          <div class="password-input password-hidden">
            <input type="password" id="new-password" name="new-password" placeholder="Enter your new password" required>
            <span class="toggle-password" onclick="togglePasswordVisibility('new-password')">
                <i class="fas"></i>
            </span>
          </div>
        </div>
        <!-- Confirm New Password Input Field -->
        <div class="form-group">
          <label for="confirm-new-password">Confirm New Password:</label>
          <div class="password-input password-hidden">
            <input type="password" id="confirm-new-password" name="confirm-new-password" placeholder="Confirm your new password" required>
            <span class="toggle-password" onclick="togglePasswordVisibility('confirm-new-password')">
                <i class="fas"></i>
            </span>
          </div>
        </div>
      <!-- Token Input Field (hidden) -->
      <input type="hidden" id="password_token" name="password_token" value="<?php echo htmlspecialchars($_GET['token']); ?>">
      <!-- Submit Button -->
      <input type="submit" value="Create New Password" name="password_reset">
      </form>
      <!-- Success Message -->
      <p class="success-message" id="success-message"></p>
      <!-- Sign-in Link -->
      <a href="signin.php" class="sign-in-link">Back to Sign In</a>
    </div>
  </div>

  <script>
    // Function to toggle password visibility
    function togglePasswordVisibility(fieldId) {
      var passwordField = document.getElementById(fieldId);
      var toggleButton = passwordField.nextElementSibling;

      if (passwordField.type === "password") {
        passwordField.type = "text"; // Show password
        toggleButton.classList.add("password-revealed");
        toggleButton.classList.remove("password-hidden");
      } else {
        passwordField.type = "password"; // Hide password
        toggleButton.classList.add("password-hidden");
        toggleButton.classList.remove("password-revealed");
      }
    }

    // Function to validate password format
    function validatePassword(password) {
      const passwordPattern = /^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
      return passwordPattern.test(password);
    }

    // Function to handle form submission
    document.getElementById('resetPasswordForm').addEventListener('submit', function(event) {
      event.preventDefault(); // Prevent the default form submission

      const newPassword = document.getElementById('new-password').value;
      const confirmNewPassword = document.getElementById('confirm-new-password').value;
      const token = document.getElementById('password_token').value;
      const successMessage = document.getElementById('success-message');
      const errorMessage = document.getElementById('errorMessages');

      // Clear previous messages
      successMessage.textContent = '';
      errorMessage.textContent = '';

      if (!validatePassword(newPassword)) {
        displayError('Password must be at least 8 characters long, include an uppercase letter, a number, and a special character.');
        return;
      }

      if (newPassword !== confirmNewPassword) {
        displayError('Passwords do not match.');
        return;
      }

      // Prepare data for sending
      const formData = new FormData();
      formData.append('new-password', newPassword);
      formData.append('confirm-new-password', confirmNewPassword);
      formData.append('password_token', token);

      console.log(formData);

      // Send the data using fetch
      fetch('../email-service.php', {
        method: 'POST',
        body: formData
      })
      .then(response => {
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
      })
      .then(data => {
        console.log('Response data:', data); // Log the response data for debugging
        if (data.error) {
          displayError(data.message);
        } else {
          displaySuccess(data.message);
        }
      })
      .catch(error => {
        console.error('Fetch error:', error); // Log the error for debugging
        displayError('An error occurred. Please try again.');
      });
    });

    // Function to display error messages
    function displayError(message) {
      const errorDiv = document.createElement('div');
      errorDiv.className = 'error';
      errorDiv.textContent = message;
      document.getElementById('errorMessages').appendChild(errorDiv);
    }

    // Function to display success messages
    function displaySuccess(message) {
      const successDiv = document.createElement('div');
      successDiv.className = 'success';
      successDiv.textContent = message;
      document.getElementById('errorMessages').appendChild(successDiv);
    }
  </script>
</body>
</html>
