<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Create New Password</title>
  <style>
    /* Body styles */
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 0;
      background: linear-gradient(135deg, #e65b00, #ffc600, #e65b00); /* Adjusted background gradient */
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    /* Container styles */
    .container {
      max-width: 400px;
      width: 100%;
      background: rgba(255, 255, 255, 0.9);
      padding: 20px;
      border-radius: 20px;
      box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.2);
      text-align: center;
      position: relative;
      overflow: hidden;
      margin-top: 50px; /* Add margin to the top */
    }

    .error {
    background-color: #ffcccc;
    color: #cc0000;
    padding: 10px;
    margin-bottom: 20px;
    border-radius: 10px;
    }

    .success {
    background-color: #ccffcc;
    color: #006600;
    padding: 10px;
    margin-bottom: 20px;
    border-radius: 10px;
    }

    /* Title styles */
    h2 {
      color: #333;
      margin-bottom: 20px;
      font-size: 32px;
      letter-spacing: 1px;
    }

    /* Form group styles */
    .form-group {
      margin-bottom: 15px;
      text-align: left;
    }

    /* Label styles */
    label {
      display: block;
      font-weight: bold;
      margin-bottom: 5px;
      color: #666;
      font-size: 16px;
    }

    /* Input styles */
    input[type="text"] {
      width: calc(100% - 24px);
      padding: 12px;
      border: none;
      border-radius: 10px;
      background-color: rgba(255, 255, 255, 0.9);
      color: #333;
      font-size: 14px;
      outline: none;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      transition: box-shadow 0.3s ease;
    }

    /* Input focus styles */
    input[type="text"]:focus {
      box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
    }

    /* Submit button styles */
    input[type="submit"] {
      width: 100%;
      padding: 15px;
      border: none;
      border-radius: 10px;
      background: linear-gradient(to right, #e65b00, #f9a825); /* Enhanced gradient for button */
      color: #fff;
      font-size: 16px;
      cursor: pointer;
      transition: transform 0.2s ease;
    }

    /* Submit button hover styles */
    input[type="submit"]:hover {
      transform: scale(1.05);
    }

    /* Success message styles */
    .success-message {
      color: green;
      margin-top: 20px;
      font-size: 18px;
    }

    /* Sign-in link styles */
    .sign-in-link {
      color: #e65b00;
      text-decoration: none;
      margin-top: 20px;
      display: block;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Enter Your Email</h2>
    <form action="../sendMail.php" method="post">
    <?php if(isset($_GET['error'])){ ?>
        <p class="error"><?php echo $_GET['error']; ?></p>
      <?php } ?>

      <?php if(isset($_GET['success'])){ ?>
        <p class="success"><?php echo $_GET['success']; ?></p>
      <?php } ?>
      <!-- Confirm New Password Input Field -->
      <div class="form-group">
        <label for="email">Email:</label>
        <input type="text" id="email" name="email" placeholder="Enter Your Email" required>
      </div>
      <!-- Submit Button -->
      <input type="submit" value="Submit">

      <a href="signin.php" class="sign-in-link">Back to Sign In</a>
    </form>

  </div>
</body>
</html>
