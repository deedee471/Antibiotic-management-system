<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sign In</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    /* Body styles */
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 0;
      background: linear-gradient(135deg, #e65b00, #ffc600, #e65b00); /* Adjusted background gradient */
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      height: 100vh; /* Full viewport height */
    }

    /* Container styles */
    .container {
      max-width: 400px;
      width: 100%;
      background: rgba(255, 255, 255, 0.9); /* Semi-transparent background */
      padding: 20px;
      border-radius: 20px; /* Rounded corners */
      box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.2); /* Box shadow */
      text-align: center;
      position: relative;
      overflow: hidden;
    }

    /* Title styles */
    h2 {
      color: #333;
      margin-bottom: 20px;
      font-size: 32px;
      letter-spacing: 1px;
    }

    /* Form group styles */
    .form-group {
      margin-bottom: 15px;
      text-align: left; /* Align labels and inputs to the left */
    }

    /* Label styles */
    label {
      display: block;
      font-weight: bold;
      margin-bottom: 5px;
      color: #666;
      font-size: 16px;
    }

    /* Input styles */
    input[type="text"],
    input[type="password"] {
      width: calc(100% - 24px); /* Full width minus padding */
      padding: 12px;
      border: none;
      border-radius: 10px; /* Rounded corners */
      background-color: rgba(255, 255, 255, 0.9); /* Semi-transparent background */
      color: #333;
      font-size: 14px;
      outline: none;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1); /* Light shadow */
      transition: box-shadow 0.3s ease; /* Smooth shadow transition */
    }

    /* Input focus styles */
    input[type="text"]:focus,
    input[type="password"]:focus {
      box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2); /* Stronger shadow on focus */
    }

    /* Submit button styles */
    input[type="submit"] {
      width: 100%;
      padding: 15px;
      border: none;
      border-radius: 10px; /* Rounded corners */
      background: linear-gradient(to right, #e65b00, #f9a825); /* Gradient background */
      color: #fff;
      margin-top: 20px;
      font-size: 16px;
      cursor: pointer; /* Pointer cursor on hover */
      transition: transform 0.2s ease; /* Smooth transform transition */
    }

    /* Submit button hover styles */
    input[type="submit"]:hover {
      transform: scale(1.05); /* Slightly increase size on hover */
    }

    .error {
    background-color: #ffcccc;
    color: #cc0000;
    padding: 10px;
    margin-bottom: 20px;
    border-radius: 10px;
    }

    .success {
    background-color: #ccffcc;
    color: #006600;
    padding: 10px;
    margin-bottom: 20px;
    border-radius: 10px;
    }

    /* Forgot password link styles */
    .forgot-password {
      font-size: 14px;
      color: #666;
      margin-top: 20px; /* Spacing from the button */
      text-decoration: none; /* Remove underline */
      display: inline-block;
      position: relative;
      z-index: 1; /* Ensure it stays above background circles */
    }

    /* Background shapes */
    .bg-circle {
      position: absolute;
      background: rgba(255, 255, 255, 0.2); /* Semi-transparent background */
      border-radius: 50%; /* Circular shape */
    }

    .error {
      background-color: #ffcccc;
      color: #cc0000;
      padding: 10px;
      margin-bottom: 20px;
      border-radius: 10px; /* Rounded corners */
    }

    .success {
      background-color: #ccffcc;
      color: #006600;
      padding: 10px;
      margin-bottom: 20px;
      border-radius: 10px; /* Rounded corners */
    }

    /* Positioning of background circles */
    .bg-circle:nth-child(1) {
      width: 150px;
      height: 150px;
      top: -75px;
      left: -75px;
    }

    .bg-circle:nth-child(2) {
      width: 250px;
      height: 250px;
      top: calc(50% - 125px);
      right: -125px;
    }

    .bg-circle:nth-child(3) {
      width: 200px;
      height: 200px;
      bottom: -100px;
      left: -100px;
    }

    /* Welcome title styles */
    .welcome-title {
      font-size: 48px;
      color: #fff;
      text-align: center;
      margin-bottom: 30px;
      text-shadow: 3px 3px 6px rgba(0, 0, 0, 0.4); /* Text shadow for depth */
      background: -webkit-linear-gradient(left, #f9a825, #e65b00); /* Gradient text */
      -webkit-background-clip: text; /* Clip gradient to text */
      -webkit-text-fill-color: transparent; /* Transparent fill for gradient text */
      animation: shine 3s linear infinite; /* Shine animation */
    }

    /* Shine animation */
    @keyframes shine {
      0% {
        background-position: -1000px;
      }
      100% {
        background-position: 1000px;
      }
    }
    
    /* Password input field */
    .password-input {
        position: relative;
    }

    /* Eye icon */
    .toggle-password {
        position: absolute;
        right: 10px;
        top: 50%;
        transform: translateY(-50%);
        cursor: pointer;
    }

    /* Show eye icon when password is hidden */
    .password-hidden .toggle-password i::before {
        content: '\f06e'; /* Change eye icon to open */
    }

    /* Hide eye icon when password is revealed */
    .password-revealed .toggle-password i::before {
        content: '\f070'; /* Change eye icon to closed */
    }

  </style>
</head>
<body>
  <!-- Welcome title -->
  <div class="welcome-title">Welcome to Victory Hospital</div>
  
  <!-- Sign-in container -->
  <div class="container">
    <!-- Background circles -->
    <div class="bg-circle"></div>
    <div class="bg-circle"></div>
    <div class="bg-circle"></div>
    
    <!-- Sign-in form title -->
    <h2>Sign In</h2>
    
    <!-- Sign-in form -->
    <form action="../login.php" method="post" class="form">
      <!-- Display error message if any -->
      <?php if(isset($_GET['error'])){ ?>
        <p class="error"><?php echo $_GET['error']; ?></p>
      <?php } ?>

      <!-- Display success message if any -->
      <?php if(isset($_GET['success'])){ ?>
        <p class="success"><?php echo $_GET['success']; ?></p>
      <?php } ?>

      <!-- Email input field -->
      <div class="form-group">
        <label for="email">Email:</label>
        <input type="text" id="email" name="email" placeholder="Enter your Email" required>
      </div>
      
      <!-- Password input field -->
      <div class="form-group">
        <label for="password">Password:</label>
        <div class="password-input password-hidden">
            <input type="password" id="password" name="password" placeholder="Enter your password" required>
            <span class="toggle-password" onclick="togglePasswordVisibility()">
                <i class="fas"></i>
            </span>
        </div>
      </div>
      
      <!-- Submit button -->
      <input type="submit" value="Sign In">
      
      <!-- Forgot password link -->
      <a href="emailPassword.php" class="forgot-password">Forgot password?</a>
    </form>
  </div>
  <script>
    // Function to toggle password visibility
    function togglePasswordVisibility() {
        var passwordField = document.getElementById("password");
        var toggleButton = document.querySelector(".toggle-password");

        if (passwordField.type === "password") {
            passwordField.type = "text"; // Show password
            toggleButton.classList.add("password-revealed");
            toggleButton.classList.remove("password-hidden");
        } else {
            passwordField.type = "password"; // Hide password
            toggleButton.classList.add("password-hidden");
            toggleButton.classList.remove("password-revealed");
        }
    }
</script>
</body>
</html>
