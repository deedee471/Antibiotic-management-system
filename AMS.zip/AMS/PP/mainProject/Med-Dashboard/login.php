<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="loginStyle.css" />
    <style>
        /* Add this style for the typing animation */
        .typing-animation::after {
            content: '|';
            animation: blink-caret 0.75s infinite alternate;
            display: inline-block;
        }

        @keyframes typing {
            from {
                width: 0;
            }

            to {
                width: 100%;
            }
        }

        @keyframes blink-caret {
            to {
                opacity: 0;
            }
        }

        .welcome-text {
            overflow: hidden;
            white-space: nowrap;
            display: inline-block;
        }
    </style>
</head>

<body class="login-container">
    <div class="login-content">
        <!-- Add unique IDs to each word for animation -->
        <h1 class="welcome-text" id="welcomeText">
            <span id="word1">Welcome</span>
            <span id="word2">to</span>
            <span id="word3">Victory</span>
            <span id="word4">Hospital</span>
        </h1>
        <p>Please login</p>
    </div>
    <form action= "../login.php" method= "post" class="form">
        <?php if(isset($_GET['error'])){ ?>
            <p class="error"><?php echo $_GET['error']; ?></p>
        <?php } ?>


        <div class="flex-column">
            <label>Email </label>
        </div>
        <div class="inputForm">
            <input placeholder="Enter your Email" class="input" type="text" name = "email">
        </div>

        <div class="flex-column">
            <label>Password </label>
        </div>
        <div class="inputForm">
            <input placeholder="Enter your Password" class="input" type="password" name = "password">
        </div>

        <div class="flex-row">
            <span class="span">Forgot password?</span>
        </div>
        <button class="signin-button" type= "submit"> Sign In</button>
    </form>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var welcomeText = document.getElementById('welcomeText');
            welcomeText.innerHTML = ''; // Clear the text
    
            // Create a single span for the entire heading
            var span = document.createElement('span');
            span.textContent = "Welcome to Victory Hospital";
            span.style.display = 'inline-block';
            span.style.overflow = 'hidden';
            span.style.whiteSpace = 'nowrap';
            span.style.animation = 'typing 4s steps(' + span.textContent.length + ') both'; // Adjust the duration
    
            welcomeText.appendChild(span);
        });
    </script>
</body>

</html>