<?php

session_start();

// Get the fullname of the logged-in user
$role = isset($_SESSION['role']) ? $_SESSION['role'] : '';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Prescription Manager</title>
  <link rel="stylesheet" href="style.css" />
</head>

<body>
<?php if($role==='DOCTOR'){ ?>
  <input type="checkbox" id="sidebar-toggle" />
  <!--side bar-->

  <div class="sidebar">
    <!--sidebar-header-->
    <div class="sidebar-header">
      <h3 class="brand">
        <span>
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-grid-1x2-fill"
            viewBox="0 0 16 16">
            <path
              d="M0 1a1 1 0 0 1 1-1h5a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H1a1 1 0 0 1-1-1V1zm9 0a1 1 0 0 1 1-1h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1h-5a1 1 0 0 1-1-1V1zm0 9a1 1 0 0 1 1-1h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1h-5a1 1 0 0 1-1-1v-5z" />
          </svg>
        </span>
        <span>Victory Hospital</span>
      </h3>
      <label for="sidebar-toggle" style="cursor: pointer">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-list"
          viewBox="0 0 16 16">
          <path fill-rule="evenodd"
            d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z" />
        </svg>
      </label>
    </div>

    <!--sidebar-menu-->
    <div class="sidebar-menu">

      <ul>
        <li>
          <a href="./index.php">
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-house"
                viewBox="0 0 16 16">
                <path fill-rule="evenodd"
                  d="M2 13.5V7h1v6.5a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5V7h1v6.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5zm11-11V6l-2-2V2.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5z" />
                <path fill-rule="evenodd"
                  d="M7.293 1.5a1 1 0 0 1 1.414 0l6.647 6.646a.5.5 0 0 1-.708.708L8 2.207 1.354 8.854a.5.5 0 1 1-.708-.708L7.293 1.5z" />
              </svg>
            </span>
            <span>Home</span>
          </a>
        </li>
        <li>
          <a href="./Patients.php">
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                class="bi bi-emoji-smile" viewBox="0 0 16 16">
                <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                <path
                  d="M4.285 9.567a.5.5 0 0 1 .683.183A3.498 3.498 0 0 0 8 11.5a3.498 3.498 0 0 0 3.032-1.75.5.5 0 1 1 .866.5A4.498 4.498 0 0 1 8 12.5a4.498 4.498 0 0 1-3.898-2.25.5.5 0 0 1 .183-.683zM7 6.5C7 7.328 6.552 8 6 8s-1-.672-1-1.5S5.448 5 6 5s1 .672 1 1.5zm4 0c0 .828-.448 1.5-1 1.5s-1-.672-1-1.5S9.448 5 10 5s1 .672 1 1.5z" />
              </svg>
            </span>
            <span>Patients</span>
          </a>
        </li>
        <li>
   <a href="./antibiotic.php">
   <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-droplet-half"
        viewBox="0 0 16 16">
        <path
          d="M4.325 11.573c-1.497-.863-2.55-1.672-2.483-2.154.083-.611.617-1.25 1.307-1.52C4.125 7.167 4.621 7 5 7c.379 0 .875.167 1.85.9.69.27 1.225.909 1.307 1.52.067.482-.986 1.29-2.482 2.153zM5.878 14.268c.337.193.724.287 1.122.287.398 0 .785-.094 1.122-.287.846-.484 1.59-1.182 2.046-1.955.443-.785.651-1.59.514-2.318-.186-1.088-.986-1.885-2.042-2.23C8.545 7.17 8.281 7 8 7c-.28 0-.544.17-.918.774-1.055.345-1.856 1.142-2.042 2.23-.137.729-.047 1.533.397 2.318.455.773 1.199 1.471 2.045 1.955zM7 2c-.584 0-1 .4-1 1v.707c0 .333-.193.598-.445.793L4 5.707V6c0 .601.107 1.229.42 1.771.107.22.233.432.374.628C4.889 8.562 5.212 8.793 5.5 9h1c.289-.207.612-.438.706-.601.141-.196.267-.408.374-.628.313-.542.42-1.17.42-1.771V5.707l-.555-.555C7.193 4.305 7 4.64 7 4.707V3c0-.6-.416-1-1-1z" />
      </svg>
    <span>Antibiotics</span>
  </a>
</li>
        <li>
          <a href="./Prescription.php">
            <span>
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-prescription" viewBox="0 0 16 16">
                    <path d="M5.5 1a.5.5 0 0 0-1 0V2H3.5A1.5 1.5 0 0 0 2 3.5v9A1.5 1.5 0 0 0 3.5 14h9a1.5 1.5 0 0 0 1.5-1.5V3.5A1.5 1.5 0 0 0 12.5 2H11V1a.5.5 0 0 0-1 0v1h-3V1zM11 3v1h-3V3h3zm0 2v1h-3V5h3zm-5.5 6A1.5 1.5 0 0 0 5 12.5v-1A.5.5 0 0 1 5.5 11h5a.5.5 0 0 1 .5.5v1a1.5 1.5 0 0 0 1.5 1.5h2v1a.5.5 0 0 1-.5.5H4a.5.5 0 0 1-.5-.5v-1h2v-1zm1.5-4a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-5a.5.5 0 0 1-.5-.5v-1z"/>
                    </svg>
            </span>
            <span>Prescription</span>
          </a>
        </li>
        <li>
        <a href="logout.php" class="logout-button">
    <span>
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-box-arrow-right" viewBox="0 0 16 16">
        <path fill-rule="evenodd" d="M10.5 12.5a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1 0-1h8a.5.5 0 0 1 .5.5zM11 8.5a.5.5 0 0 1 .5-.5h2.5a.5.5 0 0 1 .5.5v3a.5.5 0 0 1-.5.5H11a.5.5 0 0 1-.5-.5v-1a.5.5 0 0 0-1 0v1A1.5 1.5 0 0 0 11 13h2.5a1.5 1.5 0 0 0 1.5-1.5v-3a1.5 1.5 0 0 0-1.5-1.5H11a.5.5 0 0 0-.5.5v1a.5.5 0 0 1-1 0v-1a1.5 1.5 0 0 1 1.5-1.5H15a.5.5 0 0 1 .5.5v3a.5.5 0 0 1-.5.5H11a.5.5 0 0 1-.5-.5v-1a.5.5 0 0 0-1 0v1z"/>
      </svg>
    </span>
    Logout
  </a>
</li>
      </ul>
    </div>
  </div>

      
  <?php }else{ ?>

  <input type="checkbox" id="sidebar-toggle" />
  <!--side bar-->

  <div class="sidebar">
    <!--sidebar-header-->
    <div class="sidebar-header">
      <h3 class="brand">
        <span>
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-grid-1x2-fill"
            viewBox="0 0 16 16">
            <path
              d="M0 1a1 1 0 0 1 1-1h5a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H1a1 1 0 0 1-1-1V1zm9 0a1 1 0 0 1 1-1h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1h-5a1 1 0 0 1-1-1V1zm0 9a1 1 0 0 1 1-1h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1h-5a1 1 0 0 1-1-1v-5z" />
          </svg>
        </span>
        <span>DA Report</span>
      </h3>
      <label for="sidebar-toggle" style="cursor: pointer">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-list"
          viewBox="0 0 16 16">
          <path fill-rule="evenodd"
            d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z" />
        </svg>
      </label>
    </div>

    <!--sidebar-menu-->
    <div class="sidebar-menu">

      <ul>
        <li>
          <a href="./index.php">
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-house"
                viewBox="0 0 16 16">
                <path fill-rule="evenodd"
                  d="M2 13.5V7h1v6.5a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5V7h1v6.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5zm11-11V6l-2-2V2.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5z" />
                <path fill-rule="evenodd"
                  d="M7.293 1.5a1 1 0 0 1 1.414 0l6.647 6.646a.5.5 0 0 1-.708.708L8 2.207 1.354 8.854a.5.5 0 1 1-.708-.708L7.293 1.5z" />
              </svg>
            </span>
            <span>Home</span>
          </a>
        </li>
        <li>
          <a href="./Doctors.php">
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                class="bi bi-emoji-smile" viewBox="0 0 16 16">
                <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                <path
                  d="M4.285 9.567a.5.5 0 0 1 .683.183A3.498 3.498 0 0 0 8 11.5a3.498 3.498 0 0 0 3.032-1.75.5.5 0 1 1 .866.5A4.498 4.498 0 0 1 8 12.5a4.498 4.498 0 0 1-3.898-2.25.5.5 0 0 1 .183-.683zM7 6.5C7 7.328 6.552 8 6 8s-1-.672-1-1.5S5.448 5 6 5s1 .672 1 1.5zm4 0c0 .828-.448 1.5-1 1.5s-1-.672-1-1.5S9.448 5 10 5s1 .672 1 1.5z" />
              </svg>
            </span>
            <span>Doctors</span>
          </a>
        </li>
        <?php if($role==='SUPERADMIN'){ ?>
        <li>
          <a href="./Admins.php">
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                class="bi bi-emoji-smile" viewBox="0 0 16 16">
                <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                <path
                  d="M4.285 9.567a.5.5 0 0 1 .683.183A3.498 3.498 0 0 0 8 11.5a3.498 3.498 0 0 0 3.032-1.75.5.5 0 1 1 .866.5A4.498 4.498 0 0 1 8 12.5a4.498 4.498 0 0 1-3.898-2.25.5.5 0 0 1 .183-.683zM7 6.5C7 7.328 6.552 8 6 8s-1-.672-1-1.5S5.448 5 6 5s1 .672 1 1.5zm4 0c0 .828-.448 1.5-1 1.5s-1-.672-1-1.5S9.448 5 10 5s1 .672 1 1.5z" />
              </svg>
            </span>
            <span>Admins</span>
          </a>
        </li>
        <?php }?>
        
        <li>
   <a href="./antibiotic.php">
   <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-droplet-half"
        viewBox="0 0 16 16">
        <path
          d="M4.325 11.573c-1.497-.863-2.55-1.672-2.483-2.154.083-.611.617-1.25 1.307-1.52C4.125 7.167 4.621 7 5 7c.379 0 .875.167 1.85.9.69.27 1.225.909 1.307 1.52.067.482-.986 1.29-2.482 2.153zM5.878 14.268c.337.193.724.287 1.122.287.398 0 .785-.094 1.122-.287.846-.484 1.59-1.182 2.046-1.955.443-.785.651-1.59.514-2.318-.186-1.088-.986-1.885-2.042-2.23C8.545 7.17 8.281 7 8 7c-.28 0-.544.17-.918.774-1.055.345-1.856 1.142-2.042 2.23-.137.729-.047 1.533.397 2.318.455.773 1.199 1.471 2.045 1.955zM7 2c-.584 0-1 .4-1 1v.707c0 .333-.193.598-.445.793L4 5.707V6c0 .601.107 1.229.42 1.771.107.22.233.432.374.628C4.889 8.562 5.212 8.793 5.5 9h1c.289-.207.612-.438.706-.601.141-.196.267-.408.374-.628.313-.542.42-1.17.42-1.771V5.707l-.555-.555C7.193 4.305 7 4.64 7 4.707V3c0-.6-.416-1-1-1z" />
      </svg>
    <span>Antibiotics</span>
  </a>
</li>
        <li>
        <a href="logout.php" class="logout-button">
    <span>
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-box-arrow-right" viewBox="0 0 16 16">
        <path fill-rule="evenodd" d="M10.5 12.5a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1 0-1h8a.5.5 0 0 1 .5.5zM11 8.5a.5.5 0 0 1 .5-.5h2.5a.5.5 0 0 1 .5.5v3a.5.5 0 0 1-.5.5H11a.5.5 0 0 1-.5-.5v-1a.5.5 0 0 0-1 0v1A1.5 1.5 0 0 0 11 13h2.5a1.5 1.5 0 0 0 1.5-1.5v-3a1.5 1.5 0 0 0-1.5-1.5H11a.5.5 0 0 0-.5.5v1a.5.5 0 0 1-1 0v-1a1.5 1.5 0 0 1 1.5-1.5H15a.5.5 0 0 1 .5.5v3a.5.5 0 0 1-.5.5H11a.5.5 0 0 1-.5-.5v-1a.5.5 0 0 0-1 0v1z"/>
      </svg>
    </span>
    Logout
  </a>
</li>
      </ul>
    </div>
  </div>

  <?php } ?>

  <!--main-content-->
  <div class="main-content">
    <!--header-->
    <header>
      <div class="search-wrapper">
        <span>
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search"
            viewBox="0 0 16 16">
            <path
              d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
          </svg>
        </span>
        <input type="text" name="search" placeholder="Search" />
      </div>

      <div class="social-icons">
        <span>
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-bell"
            viewBox="0 0 16 16">
            <path
              d="M8 16a2 2 0 0 0 2-2H6a2 2 0 0 0 2 2zM8 1.918l-.797.161A4.002 4.002 0 0 0 4 6c0 .628-.134 2.197-.459 3.742-.16.767-.376 1.566-.663 2.258h10.244c-.287-.692-.502-1.49-.663-2.258C12.134 8.197 12 6.628 12 6a4.002 4.002 0 0 0-3.203-3.92L8 1.917zM14.22 12c.223.447.481.801.78 1H1c.299-.199.557-.553.78-1C2.68 10.2 3 6.88 3 6c0-2.42 1.72-4.44 4.005-4.901a1 1 0 1 1 1.99 0A5.002 5.002 0 0 1 13 6c0 .88.32 4.2 1.22 6z" />
          </svg>
        </span>
        <span>
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-card-text"
            viewBox="0 0 16 16">
            <path
              d="M14.5 3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h13zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13z" />
            <path
              d="M3 5.5a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zM3 8a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9A.5.5 0 0 1 3 8zm0 2.5a.5.5 0 0 1 .5-.5h6a.5.5 0 0 1 0 1h-6a.5.5 0 0 1-.5-.5z" />
          </svg>
        </span>
        <div></div>
      </div>
    </header>

    <!--main-->
    <main>
      <h2 class="dash-title">Overview</h2>

      <!--cards-->
      <?php if($role=== 'DOCTOR'){ ?>
      <div class="dash-cards">
        <div class="card-single">
          <div class="card-body">
            <div>
              <h5>Total Prescriptions</h5>
              <h4 id="prescriptionsWritten">0</h4>
            </div>
          </div>
          <div class="card-footer">
            <a href="Prescription.php">View all</a>
          </div>
        </div>

        <div class="card-single">
          <div class="card-body">

            <div>
              <h5>Total Patients</h5>
              <h4 id="totalPatients">0</h4>
            </div>
          </div>
          <div class="card-footer">
            <a href="Patients.php">View all</a>
          </div>
        </div>

        <div class="card-single">
          <div class="card-body">
            <div>
              <h5>Total Antibiotics</h5>
              <h4 id="totalAntibiotics">0</h4>
            </div>
          </div>
          <div class="card-footer">
            <a href="antibiotic.php">View all</a>
          </div>
        </div>
      </div>

      <?php }else{ ?>

        <div class="dash-cards">
        <?php if($role==='SUPERADMIN'){ ?>
        <div class="card-single">
          <div class="card-body">
            <div>
              <h5>Total Admins</h5>
              <h4 id="totalAdmins">0</h4>
            </div>
          </div>
          <div class="card-footer">
            <a href="Admins.php">View all</a>
          </div>
        </div>

        <?php }?>

        <div class="card-single">
          <div class="card-body">

            <div>
              <h5>Total Doctors</h5>
              <h4 id="totalDoctors">0</h4>
            </div>
          </div>
          <div class="card-footer">
            <a href="Doctors.php">View all</a>
          </div>
        </div>

        <div class="card-single">
          <div class="card-body">
            <div>
              <h5>Total Antibiotics</h5>
              <h4 id="totalAntibiotics">0</h4>
            </div>
          </div>
          <div class="card-footer">
            <a href="antibiotic.php">View all</a>
          </div>
        </div>
      </div>

      <?php } ?>

      <section class="recent">
        <div class="activity-grid">
          <div class="activity-card">
            <h3>Recent activity</h3>

            <table class="activity-table">
              <thead>
                <tr>
                  <th></th>
                  <th>Description</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody id="activityData">
              </tbody>
            </table>
          </div>

          </div>
        </div>
      </section>
    </main>
  </div>
  <!-- JavaScript for sidebar toggle -->
  <script>
    const sidebarToggle = document.getElementById('sidebar-toggle');
    const sidebar = document.querySelector('.sidebar');

    sidebarToggle.addEventListener('change', () => {
      sidebar.classList.toggle('open');
    });
  </script>

<script>
    // Fetch logs data from getLastFiveLogs.php
    fetch('../getLastFiveLogs.php')
        .then(response => response.json())
        .then(data => {
            // Process the JSON response
            const activityData = data.logs;

            // Populate the table with log data
            const activityTableBody = document.getElementById('activityData');
            activityTableBody.innerHTML = ''; // Clear any previous content

            if (activityData.length === 0) {
              console.log(activityData.length,"Length")
                // If no logs are available, display a message
                const noDataMessage = `
                    <tr>
                        <td colspan="3" style="text-align: center;">No recent activities related to you</td>
                    </tr>
                `;
                activityTableBody.insertAdjacentHTML('beforeend', noDataMessage);
            } else {
                // Otherwise, display the logs
                activityData.forEach(activity => {
                    const formattedDate = new Date(activity.created_at).toLocaleString();
                    const row = `
                        <tr data-activity-id="${activity._id}">
                            <td><img src="./img/loudspeaker.png" alt="Logo" style="width: 30px; height: 30px;"></td>
                            <td>${activity.action}</td>
                            <td>${formattedDate}</td>
                        </tr>
                    `;
                    activityTableBody.insertAdjacentHTML('beforeend', row);
                });
            }
        })
        .catch(error => {
            console.error('Error fetching activity data:', error);
        });
</script>

  <!-- <script>
    // Function to animate counting up from 0 to a specified target number
    function animateValue(element, start, end, duration) {
      let startTimestamp = null;
      const step = (timestamp) => {
        if (!startTimestamp) startTimestamp = timestamp;
        const progress = Math.min((timestamp - startTimestamp) / duration, 1);
        element.textContent = Math.floor(progress * (end - start) + start);
        if (progress < 1) {
          window.requestAnimationFrame(step);
        }
      };
      window.requestAnimationFrame(step);
    }
  
    // Call animateValue function for each card with the appropriate values
    const cards = document.querySelectorAll('.card-single');
    cards.forEach((card, index) => {
      const h4Element = card.querySelector('h4');
      const startValue = 0; // Start value for counting animation
      const endValue = parseInt(h4Element.textContent); // End value from the current content
      const duration = 1000; // Duration of the animation in milliseconds (adjust as needed)
      animateValue(h4Element, startValue, endValue, duration);
    });
  </script> -->
  <script>
    // Wait for the DOM content to be fully loaded before executing JavaScript
    document.addEventListener('DOMContentLoaded', function () {
      // Select the search input field and all table rows in the document
      const searchInput = document.querySelector('input[name="search"]');
      const tableRows = document.querySelectorAll('tbody tr');
  
      // Add an event listener to the search input field for input changes
      searchInput.addEventListener('input', function () {
        // Trim and convert the search term to lowercase for case-insensitive comparison
        const searchTerm = this.value.trim().toLowerCase();
  
        // Iterate over each table row
        tableRows.forEach(row => {
          // Get the text content of each cell in the row and convert to lowercase
          const prescription = row.cells[0].textContent.trim().toLowerCase();
          const date = row.cells[1].textContent.trim().toLowerCase();
          const drug = row.cells[2].textContent.trim().toLowerCase();
          const patientName = row.cells[3].textContent.trim().toLowerCase();
  
          // Check if any cell content matches the search term
          if (
            prescription.includes(searchTerm) ||
            date.includes(searchTerm) ||
            drug.includes(searchTerm) ||
            patientName.includes(searchTerm)
          ) {
            // If there is a match, display the row
            row.style.display = '';
          } else {
            // If there is no match, hide the row
            row.style.display = 'none';
          }
        });
      });
    });
  </script>

  <script>
          // Function to fetch the number of prescriptions written
      function fetchPrescriptionsWritten() {
          return fetch('../getPrescriptionCount.php')
              .then(response => response.json())
              .then(data => {

                  // Assuming the response contains the count of prescriptions written
                  const count = data.count; // Adjust this based on the actual structure of the response
                  return count;
              })
              .catch(error => {
                  console.error('Error fetching prescriptions written:', error);
                  return 'Error'; // Return an error message or placeholder value
              });
      }

      // Update the HTML content with the number of prescriptions written
      fetchPrescriptionsWritten()
          .then(count => {
              if (count !== 'Error') {
                  const prescriptionsWrittenElement = document.getElementById('prescriptionsWritten');
                  console.log(prescriptionsWrittenElement.textContent)
                  prescriptionsWrittenElement.textContent = count;
              } else {
                  console.error('Failed to fetch prescriptions written');
                  // Handle error: Display a message or take appropriate action
              }
          });
</script>

<script>
          // Function to fetch the number of prescriptions written
      function fetchPrescriptionsWritten() {
          return fetch('../getPatientsCount.php')
              .then(response => response.json())
              .then(data => {

                  // Assuming the response contains the count of prescriptions written
                  const count = data.count; // Adjust this based on the actual structure of the response
                  return count;
              })
              .catch(error => {
                  console.error('Error fetching prescriptions written:', error);
                  return 'Error'; // Return an error message or placeholder value
              });
      }

      // Update the HTML content with the number of prescriptions written
      fetchPrescriptionsWritten()
          .then(count => {
              if (count !== 'Error') {
                  const prescriptionsWrittenElement = document.getElementById('totalPatients');
                  console.log(prescriptionsWrittenElement.textContent)
                  prescriptionsWrittenElement.textContent = count;
              } else {
                  console.error('Failed to fetch prescriptions written');
                  // Handle error: Display a message or take appropriate action
              }
          });
</script>

<script>
          // Function to fetch the number of prescriptions written
      function fetchPrescriptionsWritten() {
          return fetch('../getAntibioticsCount.php')
              .then(response => response.json())
              .then(data => {

                  // Assuming the response contains the count of prescriptions written
                  const count = data.count; // Adjust this based on the actual structure of the response
                  return count;
              })
              .catch(error => {
                  console.error('Error fetching prescriptions written:', error);
                  return 'Error'; // Return an error message or placeholder value
              });
      }

      // Update the HTML content with the number of prescriptions written
      fetchPrescriptionsWritten()
          .then(count => {
              if (count !== 'Error') {
                  const prescriptionsWrittenElement = document.getElementById('totalAntibiotics');
                  console.log(prescriptionsWrittenElement.textContent)
                  prescriptionsWrittenElement.textContent = count;
              } else {
                  console.error('Failed to fetch prescriptions written');
                  // Handle error: Display a message or take appropriate action
              }
          });
</script>

<script>
          // Function to fetch the number of prescriptions written
      function fetchPrescriptionsWritten() {
          return fetch('../getAdminsCount.php')
              .then(response => response.json())
              .then(data => {

                  // Assuming the response contains the count of prescriptions written
                  const count = data.count; // Adjust this based on the actual structure of the response
                  return count;
              })
              .catch(error => {
                  console.error('Error fetching prescriptions written:', error);
                  return 'Error'; // Return an error message or placeholder value
              });
      }

      // Update the HTML content with the number of prescriptions written
      fetchPrescriptionsWritten()
          .then(count => {
              if (count !== 'Error') {
                  const prescriptionsWrittenElement = document.getElementById('totalAdmins');
                  console.log(prescriptionsWrittenElement.textContent)
                  prescriptionsWrittenElement.textContent = count;
              } else {
                  console.error('Failed to fetch prescriptions written');
                  // Handle error: Display a message or take appropriate action
              }
          });
</script>

<script>
          // Function to fetch the number of prescriptions written
      function fetchPrescriptionsWritten() {
          return fetch('../getDoctorsCount.php')
              .then(response => response.json())
              .then(data => {

                  // Assuming the response contains the count of prescriptions written
                  const count = data.count; // Adjust this based on the actual structure of the response
                  return count;
              })
              .catch(error => {
                  console.error('Error fetching prescriptions written:', error);
                  return 'Error'; // Return an error message or placeholder value
              });
      }

      // Update the HTML content with the number of prescriptions written
      fetchPrescriptionsWritten()
          .then(count => {
              if (count !== 'Error') {
                  const prescriptionsWrittenElement = document.getElementById('totalDoctors');
                  console.log(prescriptionsWrittenElement.textContent)
                  prescriptionsWrittenElement.textContent = count;
              } else {
                  console.error('Failed to fetch prescriptions written');
                  // Handle error: Display a message or take appropriate action
              }
          });
</script>

</body>
</html>