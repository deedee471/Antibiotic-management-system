<?php
// Start PHP session if not already started
session_start();

// Get the fullname of the logged-in user
$fullname = isset($_SESSION['name']) ? $_SESSION['name'] : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Page</title>
  <style>
    /* Background styles */
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background:linear-gradient(to bottom, #e65b00, #f9a825);
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    /* Container styles */
    .container {
      width: 600px; /* Adjusted width */
      background-color: rgba(255, 255, 255, 0.9);
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
    }

    /* Title styles */
    h2 {
      text-align: center;
      margin-bottom: 30px;
      color: #333;
      text-shadow: 2px 2px 2px rgba(0, 0, 0, 0.1);
    }

    /* Button styles */
    .add-button {
      background:  linear-gradient(to right, #e65b00, #f9a825);
      color: #fff;
      border: none;
      padding: 10px 20px;
      border-radius: 25px;
      cursor: pointer;
      transition: background 0.3s;
      margin-bottom: 20px;
      width: 100%;
      display: block;
      text-align: center;
      font-size: 16px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .add-button:hover {
      background:  linear-gradient(to right,#f9a825, #e65b00 );
    }

    /* Form styles */
    .form {
      display: none; /* Hide the form initially */
    }

    /* Input styles */
    .form-group {
      margin-bottom: 20px;
      text-align: left;
    }

    label {
      display: block;
      font-weight: bold;
      margin-bottom: 5px;
      color: #666;
      font-size: 16px;
    }

    input[type="text"],
    input[type="email"],
    input[type="tel"],
    select {
      width: calc(100% - 24px);
      padding: 12px;
      border: none;
      border-radius: 8px;
      background-color: rgba(255, 255, 255, 0.9);
      color: #333;
      font-size: 14px;
      outline: none;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
      transition: box-shadow 0.3s ease;
    }

    input[type="text"]:focus,
    input[type="email"]:focus,
    input[type="tel"]:focus,
    select:focus {
      box-shadow: 0 3px 6px rgba(0, 0, 0, 0.2);
    }

    /* Submit button styles */
input[type="submit"] {
  background:  linear-gradient(to right, #e65b00, #f9a825);
  color: #fff;
  border: none;
  padding: 10px 20px; /* Adjusted padding */
  border-radius: 25px;
  cursor: pointer;
  transition: background 0.3s, transform 0.2s ease; /* Added transition for transform */
  width: 100%;
  display: block;
  text-align: center;
  font-size: 16px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

input[type="submit"]:hover {
  transform: scale(1.05);
}

  </style>
</head>
<body>
  <div class="container">
    <h2>Admin Page</h2>
    <!-- Add Doctor Button -->
    <button onclick="showForm('doctorForm')" class="add-button">Add Doctor</button>
    <!-- Add Admin Button -->
    <button onclick="showForm('adminForm')" class="add-button">Add Admin</button>

    <!-- Doctor Form -->
    <form action="#" method="post" class="form" id="doctorForm" onsubmit="return validateDoctorForm()">
      <div class="form-group">
        <label for="doctorName">Name:</label>
        <input type="text" id="doctorName" name="doctorName" placeholder="Enter doctor's name" pattern="[A-Za-z]+" title="Only alphabets allowed" required>
      </div>
      <div class="form-group">
        <label for="doctorPhone">Contact Number:</label>
        <input type="tel" id="doctorPhone" name="doctorPhone" placeholder="Enter contact number" pattern="[0-9]{10}" title="Please enter 10 digits number" required>
      </div>
      <div class="form-group">
        <label for="doctorEmail">Email Address:</label>
        <input type="email" id="doctorEmail" name="doctorEmail" placeholder="Enter email address" required>
      </div>
      <div class="form-group">
        <label for="doctorGender">Gender:</label>
        <select id="doctorGender" name="doctorGender" required>
          <option value="">Select gender</option>
          <option value="male">Male</option>
          <option value="female">Female</option>
        </select>
      </div>
      <div class="form-group">
        <label for="doctorDate">Date Added:</label>
        <input type="text" id="doctorDate" name="doctorDate" placeholder="Enter date" pattern="(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[012])/((19|20)\d{2})" title="Please enter date in dd/mm/yyyy format" required>
      </div>
      <div class="form-group">
        <label for="doctorJobId">Job ID:</label>
        <input type="text" id="doctorJobId" name="doctorJobId" placeholder="Enter Job ID" pattern="[A-Z]{3}\d{5}" title="Please enter three capital letters followed by five digits" required>
      </div>
      <input type="submit" value="Add Admin" style="margin-bottom: 10px;">
      <button onclick="readDoctorDetails()" class="add-button">Read Doctor Details</button>
      <button onclick="updateDoctorDetails()" class="add-button">Update Doctor Details</button>
      <button onclick="deleteDoctorDetails()" class="add-button">Delete Doctor Details</button>
    </form>

    <!-- Admin Form -->
    <form action="#" method="post" class="form" id="adminForm" onsubmit="return validateAdminForm()">
      <div class="form-group">
        <label for="adminName">Name:</label>
        <input type="text" id="adminName" name="adminName" placeholder="Enter admin's name" pattern="[A-Za-z]+" title="Only alphabets allowed" required>
      </div>
      <div class="form-group">
        <label for="adminPhone">Contact Number:</label>
        <input type="tel" id="adminPhone" name="adminPhone" placeholder="Enter contact number" pattern="[0-9]{10}" title="Please enter 10 digits number" required>
      </div>
      <div class="form-group">
        <label for="adminEmail">Email Address:</label>
        <input type="email" id="adminEmail" name="adminEmail" placeholder="Enter email address" required>
      </div>
      <div class="form-group">
        <label for="adminGender">Gender:</label>
        <select id="adminGender" name="adminGender" required>
          <option value="">Select gender</option>
          <option value="male">Male</option>
          <option value="female">Female</option>
        </select>
      </div>
      <div class="form-group">
        <label for="adminDate">Date Added:</label>
        <input type="text" id="adminDate" name="adminDate" placeholder="Enter date" pattern="(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[012])/((19|20)\d{2})" title="Please enter date in dd/mm/yyyy format" required>
    </div>
    <div class="form-group">
      <label for="adminJobId">Job ID:</label>
      <input type="text" id="adminJobId" name="adminJobId" placeholder="Enter Job ID" pattern="[A-Z]{3}\d{5}" title="Please enter three capital letters followed by five digits" required>
    </div>
    <input type="submit" value="Add Admin" style="margin-bottom: 10px;">
    <button onclick="readAdminDetails()" class="add-button">Read Admin Details</button>
    <button onclick="updateAdminDetails()" class="add-button">Update Admin Details</button>
    <button onclick="deleteAdminDetails()" class="add-button">Delete Admin Details</button>
  </form>
</div>

<script>
  // Function to validate the Doctor form
  function validateDoctorForm() {
    var name = document.getElementById("doctorName").value;
    var phone = document.getElementById("doctorPhone").value;
    var email = document.getElementById("doctorEmail").value;
    var date = document.getElementById("doctorDate").value;
    var jobId = document.getElementById("doctorJobId").value;

    if (!name.match(/^[A-Za-z]+$/)) {
      alert("Please enter a valid name with alphabets only.");
      return false;
    }

    if (!phone.match(/^\d{10}$/)) {
      alert("Please enter a valid 10-digit phone number.");
      return false;
    }

    if (!email.match(/^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/)) {
      alert("Please enter a valid email address.");
      return false;
    }

    if (!date.match(/^(0[1-9]|[12][0-9]|3[01])\/(0[1-9]|1[012])\/((19|20)\d{2})$/)) {
      alert("Please enter a valid date in dd/mm/yyyy format.");
      return false;
    }

    if (!jobId.match(/^[A-Z]{3}\d{5}$/)) {
      alert("Please enter a valid Job ID in the format ABC12345.");
      return false;
    }

    return true;
  }

  // Function to validate the Admin form
  function validateAdminForm() {
    var name = document.getElementById("adminName").value;
    var phone = document.getElementById("adminPhone").value;
    var email = document.getElementById("adminEmail").value;
    var date = document.getElementById("adminDate").value;
    var jobId = document.getElementById("adminJobId").value;

    if (!name.match(/^[A-Za-z]+$/)) {
      alert("Please enter a valid name with alphabets only.");
      return false;
    }

    if (!phone.match(/^\d{10}$/)) {
      alert("Please enter a valid 10-digit phone number.");
      return false;
    }

    if (!email.match(/^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/)) {
      alert("Please enter a valid email address.");
      return false;
    }

    if (!date.match(/^(0[1-9]|[12][0-9]|3[01])\/(0[1-9]|1[012])\/((19|20)\d{2})$/)) {
      alert("Please enter a valid date in dd/mm/yyyy format.");
      return false;
    }

    if (!jobId.match(/^[A-Z]{3}\d{5}$/)) {
      alert("Please enter a valid Job ID in the format ABC12345.");
      return false;
    }

    return true;
  }

  function showForm(formId) {
    var forms = document.getElementsByClassName("form");
    for (var i = 0; i < forms.length; i++) {
      forms[i].style.display = "none";
    }
    document.getElementById(formId).style.display = "block";
  }
</script>
</body>
</html>