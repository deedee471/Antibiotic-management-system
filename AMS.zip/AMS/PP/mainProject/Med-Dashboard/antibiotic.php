<?php

session_start();

// Get the fullname of the logged-in user
$role = isset($_SESSION['role']) ? $_SESSION['role'] : '';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>antibiotics</title>
    <link rel="stylesheet" href="style.css" />
    <style>
         /* Custom CSS for button styling */
         .view-button,
         .add-button,
        .edit-button,
        .delete-button {
            background: linear-gradient(to right, #e65b00, #f9a825);
            color: #fff; /* Text color */
            border: none;
            padding: 8px 10px;
            border-radius: 5px; /* Rounded corners */
            cursor: pointer;
            transition: background 0.3s; /* Smooth transition for hover effect */
        }

        /* Hover effect */
        .view-button:hover,
        .add-button:hover,
        .edit-button:hover,
        .delete-button:hover {
            background: linear-gradient(to right, #f9a825, #e65b00); /* Reverse gradient on hover */
        }

        /* Antibiotics Information Table */
        .antibiotic-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            font-size: 16px;
        }

        .antibiotic-table th,
        .antibiotic-table td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }

        .antibiotic-table th {
            background-color: #f2f2f2;
        }

        .antibiotic-table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .antibiotic-table tbody tr:hover {
            background-color: #e5e5e5;
        }
    </style>
</head>
<body>
<?php if($role==='DOCTOR'){ ?>
  <input type="checkbox" id="sidebar-toggle" />
  <!--side bar-->

  <div class="sidebar">
    <!--sidebar-header-->
    <div class="sidebar-header">
      <h3 class="brand">
        <span>
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-grid-1x2-fill"
            viewBox="0 0 16 16">
            <path
              d="M0 1a1 1 0 0 1 1-1h5a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H1a1 1 0 0 1-1-1V1zm9 0a1 1 0 0 1 1-1h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1h-5a1 1 0 0 1-1-1V1zm0 9a1 1 0 0 1 1-1h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1h-5a1 1 0 0 1-1-1v-5z" />
          </svg>
        </span>
        <span>DA Report</span>
      </h3>
      <label for="sidebar-toggle" style="cursor: pointer">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-list"
          viewBox="0 0 16 16">
          <path fill-rule="evenodd"
            d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z" />
        </svg>
      </label>
    </div>

    <!--sidebar-menu-->
    <div class="sidebar-menu">

      <ul>
        <li>
          <a href="./index.php">
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-house"
                viewBox="0 0 16 16">
                <path fill-rule="evenodd"
                  d="M2 13.5V7h1v6.5a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5V7h1v6.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5zm11-11V6l-2-2V2.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5z" />
                <path fill-rule="evenodd"
                  d="M7.293 1.5a1 1 0 0 1 1.414 0l6.647 6.646a.5.5 0 0 1-.708.708L8 2.207 1.354 8.854a.5.5 0 1 1-.708-.708L7.293 1.5z" />
              </svg>
            </span>
            <span>Home</span>
          </a>
        </li>
        <li>
          <a href="./Patients.php">
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                class="bi bi-emoji-smile" viewBox="0 0 16 16">
                <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                <path
                  d="M4.285 9.567a.5.5 0 0 1 .683.183A3.498 3.498 0 0 0 8 11.5a3.498 3.498 0 0 0 3.032-1.75.5.5 0 1 1 .866.5A4.498 4.498 0 0 1 8 12.5a4.498 4.498 0 0 1-3.898-2.25.5.5 0 0 1 .183-.683zM7 6.5C7 7.328 6.552 8 6 8s-1-.672-1-1.5S5.448 5 6 5s1 .672 1 1.5zm4 0c0 .828-.448 1.5-1 1.5s-1-.672-1-1.5S9.448 5 10 5s1 .672 1 1.5z" />
              </svg>
            </span>
            <span>Patients</span>
          </a>
        </li>
        <li>
   <a href="./antibiotic.php">
   <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-droplet-half"
        viewBox="0 0 16 16">
        <path
          d="M4.325 11.573c-1.497-.863-2.55-1.672-2.483-2.154.083-.611.617-1.25 1.307-1.52C4.125 7.167 4.621 7 5 7c.379 0 .875.167 1.85.9.69.27 1.225.909 1.307 1.52.067.482-.986 1.29-2.482 2.153zM5.878 14.268c.337.193.724.287 1.122.287.398 0 .785-.094 1.122-.287.846-.484 1.59-1.182 2.046-1.955.443-.785.651-1.59.514-2.318-.186-1.088-.986-1.885-2.042-2.23C8.545 7.17 8.281 7 8 7c-.28 0-.544.17-.918.774-1.055.345-1.856 1.142-2.042 2.23-.137.729-.047 1.533.397 2.318.455.773 1.199 1.471 2.045 1.955zM7 2c-.584 0-1 .4-1 1v.707c0 .333-.193.598-.445.793L4 5.707V6c0 .601.107 1.229.42 1.771.107.22.233.432.374.628C4.889 8.562 5.212 8.793 5.5 9h1c.289-.207.612-.438.706-.601.141-.196.267-.408.374-.628.313-.542.42-1.17.42-1.771V5.707l-.555-.555C7.193 4.305 7 4.64 7 4.707V3c0-.6-.416-1-1-1z" />
      </svg>
    <span>Antibiotics</span>
  </a>
</li>
        <li>
          <a href="./Prescription.php">
            <span>
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-prescription" viewBox="0 0 16 16">
                    <path d="M5.5 1a.5.5 0 0 0-1 0V2H3.5A1.5 1.5 0 0 0 2 3.5v9A1.5 1.5 0 0 0 3.5 14h9a1.5 1.5 0 0 0 1.5-1.5V3.5A1.5 1.5 0 0 0 12.5 2H11V1a.5.5 0 0 0-1 0v1h-3V1zM11 3v1h-3V3h3zm0 2v1h-3V5h3zm-5.5 6A1.5 1.5 0 0 0 5 12.5v-1A.5.5 0 0 1 5.5 11h5a.5.5 0 0 1 .5.5v1a1.5 1.5 0 0 0 1.5 1.5h2v1a.5.5 0 0 1-.5.5H4a.5.5 0 0 1-.5-.5v-1h2v-1zm1.5-4a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-5a.5.5 0 0 1-.5-.5v-1z"/>
                    </svg>
            </span>
            <span>Prescription</span>
          </a>
        </li>
        <li>
        <a href="logout.php" class="logout-button">
    <span>
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-box-arrow-right" viewBox="0 0 16 16">
        <path fill-rule="evenodd" d="M10.5 12.5a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1 0-1h8a.5.5 0 0 1 .5.5zM11 8.5a.5.5 0 0 1 .5-.5h2.5a.5.5 0 0 1 .5.5v3a.5.5 0 0 1-.5.5H11a.5.5 0 0 1-.5-.5v-1a.5.5 0 0 0-1 0v1A1.5 1.5 0 0 0 11 13h2.5a1.5 1.5 0 0 0 1.5-1.5v-3a1.5 1.5 0 0 0-1.5-1.5H11a.5.5 0 0 0-.5.5v1a.5.5 0 0 1-1 0v-1a1.5 1.5 0 0 1 1.5-1.5H15a.5.5 0 0 1 .5.5v3a.5.5 0 0 1-.5.5H11a.5.5 0 0 1-.5-.5v-1a.5.5 0 0 0-1 0v1z"/>
      </svg>
    </span>
    Logout
  </a>
</li>
      </ul>
    </div>
  </div>

      
  <?php }else{ ?>

  <input type="checkbox" id="sidebar-toggle" />
  <!--side bar-->

  <div class="sidebar">
    <!--sidebar-header-->
    <div class="sidebar-header">
      <h3 class="brand">
        <span>
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-grid-1x2-fill"
            viewBox="0 0 16 16">
            <path
              d="M0 1a1 1 0 0 1 1-1h5a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H1a1 1 0 0 1-1-1V1zm9 0a1 1 0 0 1 1-1h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1h-5a1 1 0 0 1-1-1V1zm0 9a1 1 0 0 1 1-1h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1h-5a1 1 0 0 1-1-1v-5z" />
          </svg>
        </span>
        <span>DA Report</span>
      </h3>
      <label for="sidebar-toggle" style="cursor: pointer">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-list"
          viewBox="0 0 16 16">
          <path fill-rule="evenodd"
            d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z" />
        </svg>
      </label>
    </div>

    <!--sidebar-menu-->
    <div class="sidebar-menu">

      <ul>
        <li>
          <a href="./index.php">
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-house"
                viewBox="0 0 16 16">
                <path fill-rule="evenodd"
                  d="M2 13.5V7h1v6.5a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5V7h1v6.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5zm11-11V6l-2-2V2.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5z" />
                <path fill-rule="evenodd"
                  d="M7.293 1.5a1 1 0 0 1 1.414 0l6.647 6.646a.5.5 0 0 1-.708.708L8 2.207 1.354 8.854a.5.5 0 1 1-.708-.708L7.293 1.5z" />
              </svg>
            </span>
            <span>Home</span>
          </a>
        </li>
        <li>
          <a href="./Doctors.php">
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                class="bi bi-emoji-smile" viewBox="0 0 16 16">
                <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                <path
                  d="M4.285 9.567a.5.5 0 0 1 .683.183A3.498 3.498 0 0 0 8 11.5a3.498 3.498 0 0 0 3.032-1.75.5.5 0 1 1 .866.5A4.498 4.498 0 0 1 8 12.5a4.498 4.498 0 0 1-3.898-2.25.5.5 0 0 1 .183-.683zM7 6.5C7 7.328 6.552 8 6 8s-1-.672-1-1.5S5.448 5 6 5s1 .672 1 1.5zm4 0c0 .828-.448 1.5-1 1.5s-1-.672-1-1.5S9.448 5 10 5s1 .672 1 1.5z" />
              </svg>
            </span>
            <span>Doctors</span>
          </a>
        </li>
        <?php if($role==='SUPERADMIN'){ ?>
        <li>
          <a href="./Admins.php">
            <span>
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                class="bi bi-emoji-smile" viewBox="0 0 16 16">
                <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                <path
                  d="M4.285 9.567a.5.5 0 0 1 .683.183A3.498 3.498 0 0 0 8 11.5a3.498 3.498 0 0 0 3.032-1.75.5.5 0 1 1 .866.5A4.498 4.498 0 0 1 8 12.5a4.498 4.498 0 0 1-3.898-2.25.5.5 0 0 1 .183-.683zM7 6.5C7 7.328 6.552 8 6 8s-1-.672-1-1.5S5.448 5 6 5s1 .672 1 1.5zm4 0c0 .828-.448 1.5-1 1.5s-1-.672-1-1.5S9.448 5 10 5s1 .672 1 1.5z" />
              </svg>
            </span>
            <span>Admins</span>
          </a>
        </li>
        <?php }?>
        
        <li>
   <a href="./antibiotic.php">
   <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-droplet-half"
        viewBox="0 0 16 16">
        <path
          d="M4.325 11.573c-1.497-.863-2.55-1.672-2.483-2.154.083-.611.617-1.25 1.307-1.52C4.125 7.167 4.621 7 5 7c.379 0 .875.167 1.85.9.69.27 1.225.909 1.307 1.52.067.482-.986 1.29-2.482 2.153zM5.878 14.268c.337.193.724.287 1.122.287.398 0 .785-.094 1.122-.287.846-.484 1.59-1.182 2.046-1.955.443-.785.651-1.59.514-2.318-.186-1.088-.986-1.885-2.042-2.23C8.545 7.17 8.281 7 8 7c-.28 0-.544.17-.918.774-1.055.345-1.856 1.142-2.042 2.23-.137.729-.047 1.533.397 2.318.455.773 1.199 1.471 2.045 1.955zM7 2c-.584 0-1 .4-1 1v.707c0 .333-.193.598-.445.793L4 5.707V6c0 .601.107 1.229.42 1.771.107.22.233.432.374.628C4.889 8.562 5.212 8.793 5.5 9h1c.289-.207.612-.438.706-.601.141-.196.267-.408.374-.628.313-.542.42-1.17.42-1.771V5.707l-.555-.555C7.193 4.305 7 4.64 7 4.707V3c0-.6-.416-1-1-1z" />
      </svg>
    <span>Antibiotics</span>
  </a>
</li>
        <li>
        <a href="logout.php" class="logout-button">
    <span>
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-box-arrow-right" viewBox="0 0 16 16">
        <path fill-rule="evenodd" d="M10.5 12.5a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1 0-1h8a.5.5 0 0 1 .5.5zM11 8.5a.5.5 0 0 1 .5-.5h2.5a.5.5 0 0 1 .5.5v3a.5.5 0 0 1-.5.5H11a.5.5 0 0 1-.5-.5v-1a.5.5 0 0 0-1 0v1A1.5 1.5 0 0 0 11 13h2.5a1.5 1.5 0 0 0 1.5-1.5v-3a1.5 1.5 0 0 0-1.5-1.5H11a.5.5 0 0 0-.5.5v1a.5.5 0 0 1-1 0v-1a1.5 1.5 0 0 1 1.5-1.5H15a.5.5 0 0 1 .5.5v3a.5.5 0 0 1-.5.5H11a.5.5 0 0 1-.5-.5v-1a.5.5 0 0 0-1 0v1z"/>
      </svg>
    </span>
    Logout
  </a>
</li>
      </ul>
    </div>
  </div>

  <?php } ?>
  
  <!-- Main Content -->
<div class="main-content">
    <!-- Header -->
    <header>
        <div class="search-wrapper">
            <span>
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                    class="bi bi-search" viewBox="0 0 16 16">
                    <path
                        d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
                </svg>
            <input type="text" id="searchInput" name="search" placeholder="Search" />
        </div>
    </header>
     <!-- Main -->
     <main>
        <h2 class="dash-title">Antibiotics Information</h2>

        <!-- Table for Antibiotics Information -->
        <div class="table-container">
            <!-- Button to add a new antibiotic -->
            <?php if($role=== 'ADMIN' || $role=== 'SUPERADMIN'){ ?>
            <a href="./addantibiotic.php" class="add-button">Add Antibiotic</a>
            <?php } ?>
            <table class="antibiotic-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Manufacturer</th>
                        <th>Age Range</th>
                        <th>Quantity</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="antibioticData">
                </tbody>
            </table>
        </div>
    </main>
</div>

<script>
        // Fetch antibiotic data from getallantibiotics.php
        fetch('../getAllAntibiotics.php')
            .then(response => response.json())
            .then(data => {
                // Process the JSON response
                const antibioticData = data.antibiotics;

                // Populate the table with antibiotic data
                const antibioticTableBody = document.getElementById('antibioticData');
                antibioticData.forEach(antibiotic => {
                    const row = `
                        <tr data-antibiotic-id="${antibiotic._id}">
                            <td>${antibiotic.name}</td>
                            <td>${antibiotic.description}</td>
                            <td>${antibiotic.manufacturer}</td>
                            <td>${antibiotic.age_range}</td>
                            <td>${antibiotic.quantity}</td>
                            <td>
                                <button class="view-button">Edit</button>
                                <?php if($role==='ADMIN' || $role=== 'SUPERADMIN'){ ?>
                                <button class="delete-button">Delete</button>
                                <?php } ?>
                            </td>
                        </tr>
                    `;
                    antibioticTableBody.insertAdjacentHTML('beforeend', row);
                });
            })
            .catch(error => {
                console.error('Error fetching antibiotic data:', error);
            });
    </script>

    <script>
        // JavaScript functionality for searching antibiotics based on name or contact number
        document.getElementById("searchInput").addEventListener("keyup", function () {
            let filter = this.value.toLowerCase();
            let rows = document.getElementById("antibioticData").rows;

            for (let i = 0; i < rows.length; i++) {
                let name = rows[i].cells[0].textContent.toLowerCase();
                let contact = rows[i].cells[2].textContent.toLowerCase();
                if (name.indexOf(filter) > -1 || contact.indexOf(filter) > -1) {
                    rows[i].style.display = "";
                } else {
                    rows[i].style.display = "none";
                }
            }
        });

        // JavaScript functionality for deleting a prescription
        document.querySelectorAll(".delete-button").forEach(button => {
            button.addEventListener("click", function () {
                // Your logic for deleting a prescription goes here
                console.log("Delete Prescription clicked");
            });
        });
    </script>
    <script>
        // Function to parse query parameters from URL
        function getQueryParameter(name) {
            const urlParams = new URLSearchParams(window.location.search);
            return urlParams.get(name);
        }

        // Retrieve antibiotic details from query parameters
        const name = getQueryParameter('name');
        const gender = getQueryParameter('gender');
        const contact = getQueryParameter('contact');
        const prescription = getQueryParameter('prescription');

        // Update HTML content with antibiotic details
        document.getElementById('antibiotic-details').innerHTML = `
            <p><strong>Name:</strong> ${name}</p>
            <p><strong>Gender:</strong> ${gender}</p>
            <p><strong>Contact Number:</strong> ${contact}</p>
            <p><strong>Name:</strong> ${name}</p>
            <p><strong>Gender:</strong> ${gender}</p>
            <p><strong>Contact Number:</strong> ${contact}</p>

        `;
    </script>

    <script>
        // JavaScript functionality for viewing antibiotic details
        document.addEventListener("click", function(event) {
            if (event.target && event.target.classList.contains("view-button")) {
                // Get the row corresponding to the clicked button
                let row = event.target.closest('tr');

                // Extract antibiotic ID from the row's data attribute
                let antibioticId = row.getAttribute('data-antibiotic-id');

                // Construct the URL with antibiotic ID
                let url = `editantibiotic.php?antibioticId=${encodeURIComponent(antibioticId)}`;

                // Redirect to antibioticprofile.php with the antibiotic ID
                window.location.href = url;
            }
        });
</script>

<script>
        // JavaScript functionality for viewing antibiotic details
        document.addEventListener("click", function(event) {
            if (event.target && event.target.classList.contains("renew-button")) {
                // Get the row corresponding to the clicked button
                let row = event.target.closest('tr');

                // Extract antibiotic ID from the row's data attribute
                let antibioticId = row.getAttribute('data-antibiotic-id');

                // Construct the URL with antibiotic ID
                let url = `editantibiotic.php?antibioticId=${encodeURIComponent(antibioticId)}`;

                // Redirect to antibioticprofile.php with the antibiotic ID
                window.location.href = url;
            }
        });
</script>


<script>
// Function to confirm patient deletion

        // JavaScript functionality for viewing patient details
    document.addEventListener("click", function(event) {
    if (event.target && event.target.classList.contains("delete-button")) {
        // Get the row corresponding to the clicked button
        let row = event.target.closest('tr');

        // Extract patient ID from the row's data attribute
        let antibioticId = row.getAttribute('data-antibiotic-id');

        if (confirm("Are you sure you want to delete this antibiotic's information?")) {
            // Make an AJAX request to delete the patient
            fetch(`../deleteAntibiotic.php?antibioticId=${encodeURIComponent(antibioticId)}`)
                .then(response => response.json())
                .then(data => {
                    console.log(data)
                    // Check if deletion was successful
                    if (data.error) {
                        alert('Failed to delete antibiotic: ' + data.message);
                    } else {
                        // If deletion was successful, remove the row from the table
                        row.remove();
                        alert('Antibiotic deleted successfully.');
                    }
                })
                .catch(error => {
                    console.error('Error deleting antibiotic:', error);
                    alert('An error occurred while deleting the antibiotic.');
                });
        }
    }
});


</script>

</body>
</html>